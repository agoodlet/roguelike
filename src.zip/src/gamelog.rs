pub struct GameLog {
    pub entries: Vec<String>,
}